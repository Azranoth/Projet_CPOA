#ifndef IMGGRADIENT
#define IMGGRADIENT

#include "image2grey.h"

/**
 * @brief The GradientSobel class
 *
 * Hérite de Image2Grey
 *
 * Utilisée pour générer, à partir d'une image en niveau de gris sur laquelle on passe un filtre Sobel, une nouvelle image
 */
class GradientSobel : public Image2Grey {

public:
    GradientSobel(const int x, const int y) : Image2Grey(x,y){}
    GradientSobel(const int x, const int y, unsigned char *input) : Image2Grey(x,y,input){}

    /**
     * @brief gradient55
     * @return Image2D<Vec2f>
     *
     * Renvoie l'image obtenue en passant un filtre Sobel avec un noyau 5x5 sur l'image courante
     * NON FONCTIONNEL
     */
    Image2D<Vec2f> gradient55();

/*

    static const int Sobel5x[25]={1,2,0,-2,-1,
                                          4,8,0,-8,-4,
                                          6,12,0,-12,-6,
                                          4,8,0,-8,-4,
                                          1,2,0,-2,-1};

    static const int Sobel5y[25]={1, 4, 6, 4, 1,
                                          2, 8, 12, 8, 2,
                                          0, 0, 0, 0, 0,
                                          -2,-8,-12,-8,-2,
                                          -1,-4,-6,-4,-1};

*/
};

#endif // IMGGRADIENT

