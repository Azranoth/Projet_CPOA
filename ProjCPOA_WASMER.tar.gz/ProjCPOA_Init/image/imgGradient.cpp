
#include "imggradient.h"


Image2D<Vec2f> GradientSobel::gradient55(){

    Image2D<Vec2f> res = Image2D<Vec2f>(_w, _h);
/*
    for(int i = 0; i < _h; i++){
        for(int j = 0; j < _w; j++){

            // Convolution en x
            int convol_x = 0;
            int convol_idx = 0;

            for(int x = std::max(0, j-2); x < std::min(j+2, _w); x++){
                for(int y = std::max(0, i-2); y < std::min(i+2, _w); y++){

                    convol_x += (*this)(x,y)*sobel5x[convol_idx];
                    convol_idx++;
                }
            }

            // Convolution en y
            int convol_y = 0;
            convol_idx = 0;

            for(int x = std::max(0, j-2); x < std::min(j+2, _w); x++)
            {
                for(int y = std::max(0, i-2); y < std::min(i+2, _w); y++)
                {
                    convol_y += (*this)(x,y)*sobel5y[convol_idx];
                    convol_idx++;
                }
            }

            res(j,i)[0] = convol_x;
            res(j,i)[1] = convol_y;
        }
    }
*/
    return res;
}
